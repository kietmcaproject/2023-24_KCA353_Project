
<footer class="footer footer-alt">
    2023 - <?php echo date('Y'); ?> &copy; Hospital Management System. Developed By Ms. SHEREEN</a>
</footer>

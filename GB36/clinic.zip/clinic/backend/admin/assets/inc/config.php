<?php
$dbuser="root";
$dbpass="";
$host="localhost";
$db="hms_code_camp_bd";
$mysqli=new mysqli($host,$dbuser, $dbpass, $db);
?>

<footer class="footer footer-alt">
    2023 - <?php echo date('Y'); ?> &copy; Hospital Management Information System. Developed By <a href=" ">Ms. SHEREEN</a></a>

</footer>
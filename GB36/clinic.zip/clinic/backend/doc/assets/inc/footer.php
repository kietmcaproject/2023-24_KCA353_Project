
<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                2023 - <?php echo date('Y'); ?> &copy; Hospital Management Information System. Developed By <a href="v">Ms. SHEREEN</a></a>
            </div>
            
        </div>
    </div>
</footer>
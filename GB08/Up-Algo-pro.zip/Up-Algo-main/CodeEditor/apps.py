from django.apps import AppConfig


class CodeeditorConfig(AppConfig):
    name = 'CodeEditor'

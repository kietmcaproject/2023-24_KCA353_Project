<?php 
	include '../config/connection.php';

  	$patientId = $_GET['patient_id'];

    $data = '';
   
    $query = "SELECT distinct `r`.`report`, `r`.`rep_name`
    from `reports` as `r`,  `patient_visits` as `pv`
    where `pv`.`patient_id` = $patientId and 
    `r`.`id` = `pv`.`patient_id`;";

    try {
      $stmt = $con->prepare($query);
      $stmt->execute();
      
      // if(!$r = $stmt->fetch(PDO::FETCH_ASSOC)) {
      //   // No data found
      //   $data .= '<tr><td colspan="3" class="text-center">No records found</td></tr>';
      // }
      
     
      $i = 0;
      while($r = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $i++;
        $data = $data.'<tr>';
        
        $data = $data.'<td class="px-2 py-1 align-middle text-center">'.$i.'</td>';
        $data = $data.'<td class="px-2 py-1 align-middle text-right"><img src="user_images/'.$r['report'].'"  alt="Image not found" onerror="this.onerror=null;this.src=\'user_images/pdf_image.png\';" height="100" width="100" /></td>';
        $data = $data.'<td class="px-2 py-1 align-middle text-center">'.$r['rep_name'].'</td>';
        $data = $data.'<td><a href="user_images/'.$r['report'].'" download class=" align-middle text-center btn btn-primary btn-sm btn-flat" onclick="myFunction()">Download</a></td>';
      
      }       
       
      }

    catch(PDOException $ex) {
      echo $ex->getTraceAsString();
      echo $ex->getMessage();
      exit;
    }

  	echo $data;

    
?>

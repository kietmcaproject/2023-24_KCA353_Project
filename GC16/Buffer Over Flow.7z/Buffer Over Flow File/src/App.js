import React from 'react';
import './App.css';
import Header from './components/Header/Header';
import {
  BrowserRouter as Router,Routes, Route, Redirect,
} from 'react-router-dom'
import Question from './components/Add-Question/Question';
import ViewQuestion from "./components/ViewQuestion"
import BufferOverflow from './components/BufferOverFlow';
import About from './components/About';

function App() {
  return (
    <div className="App">
      <Router>
      <Header />
        <Routes>
        <Route exact path="/" Component={BufferOverflow}></Route>
        <Route exact path="/add-question" Component={Question}></Route>
        <Route exact path="/question" Component={ViewQuestion}></Route>
        <Route exact path="/about" Component={About}></Route>
          
          
          
          
        </Routes>
      </Router>
     
     
    </div>
  );
}

export default App;

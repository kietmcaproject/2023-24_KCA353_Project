import React from 'react'
import { Avatar } from "@mui/material";
import { Link } from 'react-router-dom';
import './css/QuestionWall.css'

function QuestionWall() {
  return (
    <div className="question-wall">
      <div className="question-wall-container">
        <div className="question-wall-left">
          <div className="all-options">
            <div className="all-option">
              <p>0</p>
              <span>Support</span>
            </div>
            <div className="all-option">
              <p>0</p>
              <span>Answers</span>
            </div>
            <div className="all-option">
              <small>0 Views</small>
            </div>
          </div>
        </div>
        <div className="question-answer">
          <Link to="/question">How to make a product that is a product?</Link>

          <div
            style={{
              maxWidth: "90%",
            }}
          >
            <div  className='answer-color'>Optional. The color of the shadow. Look at CSS Color Values for a complete list of possible color values</div>
          </div>
          <div
            style={{
              display: "flex",
            }}
          >
           <span className='question-tags'>react</span>
           <span className='question-tags'>antd</span>
           <span className='question-tags'>frontend</span>
          </div>
          <div className="author">
            <small>Timestamp</small>
            <div className="author-details">
              <Avatar />
              <p>
                User name
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default QuestionWall
import React from 'react'
import './css/index.css'
import Main from './Main'
import Sidebar from './Sidebar'


function index() {
  return (
    <div className='buffer-index'>
        <div className='buffer-index-content'>
            <Sidebar />
            <Main />
        </div>   
    </div>
  )
}

export default index
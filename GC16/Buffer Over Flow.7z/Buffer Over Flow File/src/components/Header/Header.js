 import React from 'react'
 import './css/Header.css'
 import backimg from "../../assets/logo.png"
 import SearchIcon from "@mui/icons-material/Search";

 import { Link, NavLink } from 'react-router-dom'
 import AllInboxIcon from '@mui/icons-material/AllInbox';
 import { Avatar } from "@mui/material";
 

 function Header() {
   return (
     <header>
      <div className="header-container">
        <div className="header-left">
            <Link to ="/"><img
              src={backimg}
              alt="logo" className='immg'
            /></Link>
            
          
          <Link to="/about"><h3 className='hel'>About</h3></Link>
        
          
        </div>
        <div className="header-middle">
          <div className="header-search-container">
            <SearchIcon />
            <input type="text" placeholder="Search..." />
          </div>
        </div>
        <div className="header-right">
          <div className="header-right-container">
            <Avatar />
            <AllInboxIcon />
          </div>
        </div>
      </div>
     </header>
   )
 }
  
 export default Header
import React from 'react'
import '../BufferOverFlow/css/index.css'
import About from './about'
import Sidebar from '../BufferOverFlow/Sidebar'


function index() {
  return (
    <div className='buffer-index'>
        <div className='buffer-index-content'>
            <Sidebar />
            <About />
        </div>   
    </div>
  )
}

export default index
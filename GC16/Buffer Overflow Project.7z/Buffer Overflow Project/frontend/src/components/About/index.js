import React from 'react'
import '../BufferOverFlow/css/index.css'
import About from './about'



function index() {
  return (
    <div className='buffer-index'>
        <div className='buffer-index-content'>
            
            <About />
        </div>   
    </div>
  )
}

export default index
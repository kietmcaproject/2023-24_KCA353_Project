import Cart from "../features/cart/Cart";

function CartPage() {
    return <div>
        <Cart></Cart>
    </div>;
}

export default CartPage;
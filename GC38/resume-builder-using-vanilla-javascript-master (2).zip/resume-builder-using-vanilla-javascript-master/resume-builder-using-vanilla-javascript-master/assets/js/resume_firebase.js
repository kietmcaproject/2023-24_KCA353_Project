// import { handleLogout } from './firebase_auth.js';
// const firebaseConfig = {
//     apiKey: "AIzaSyBF8h7l7x-2da3SPJSE8q3wLoop9HxDYg0",
//     authDomain: "resume-eba62.firebaseapp.com",
//     databaseURL: "https://resume-eba62-default-rtdb.firebaseio.com",
//     projectId: "resume-eba62",
//     storageBucket: "resume-eba62.appspot.com",
//     messagingSenderId: "197067226999",
//     appId: "1:197067226999:web:359b6eca20ab611319ab72"
// };

// // Initialize Firebase
// const app = firebase.initializeApp(firebaseConfig);
// const auth = firebase.auth();
// const logoutId = localStorage.getItem("logoutId");
// // const loginLinkId = localStorage.getItem("loginLinkId");
// // const usernameDisplayContainerId = localStorage.getItem("usernameDisplayContainerId");


// // // Use the IDs as needed
// const logoutBtn = document.getElementById(logoutId);
// // const loginLink = document.getElementById(loginLinkId);
// // console.log(signupLinkId,loginLinkId);

// // Event listener for the logout button on "resume.html"
// document.getElementById("logoutresume").addEventListener("click", function () {
//     auth.signOut()
//         .then(() => {
//             // Redirect to the index page after successful logout

//             window.location.href = "index.html";
//         })
//         .catch((error) => {
//             console.error("Logout error:", error.message);
//             alert("Logout failed. Please try again.");
//         });
// });

// auth.onAuthStateChanged((user) => {
//     if (!user) {
//         // User is not logged in, redirect to index page
//         // document.getElementById("loginLinkId").style.display = "block";
//         // document.getElementById("signupLinkId").style.display = "block";
//         // document.getElementById("usernameDisplayContainer").style.display = "none";

//         window.location.href = "index.html";

//         setTimeout(() => {
//             // Trigger a click event on the link

//             if (logoutBtn) {
//                 logoutBtn.click();
//                 logoutBtn.addEventListener("click", handleLogout);
//             }
//         }, 1000);
        
       


//     } else {
//         // Add additional actions if needed
//     }
// });




// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBF8h7l7x-2da3SPJSE8q3wLoop9HxDYg0",
  authDomain: "resume-eba62.firebaseapp.com",
  databaseURL: "https://resume-eba62-default-rtdb.firebaseio.com",
  projectId: "resume-eba62",
  storageBucket: "resume-eba62.appspot.com",
  messagingSenderId: "197067226999",
  appId: "1:197067226999:web:359b6eca20ab611319ab72"
};

// Initialize Firebase
const app = firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();

function showError(message) {
  const errorContainer = document.getElementById("errorContainer");
  errorContainer.textContent = message;
  errorContainer.style.display = "block";
}
auth.setPersistence(firebase.auth.Auth.Persistence.LOCAL);



//Event listener for the Sign Up button
document.getElementById("signupBtn").addEventListener("click", function () {
  const email = document.getElementById("username").value;
  const password = document.getElementById("pwd").value;

  // Firebase sign-up
  disableButton('signupBtn');
  auth.createUserWithEmailAndPassword(email, password)
    .then((userCredential) => {
      // Signed up successfully
      const user = userCredential.user;
      console.log("User signed up:", user);
      alert("Signup successfully");

        // Reset input fields
        email.value = '';
        password.value = '';
  
      const displayName = user.displayName;
      // Update the username display
      const usernameDisplay = document.getElementById("usernameDisplay");

      localStorage.setItem("userEmail", user.email);
      // Update the navbar with the username
      document.getElementById("usernameDisplay").textContent = ` ${user.email}!`;
      

      const modal = new bootstrap.Modal(document.getElementById("exampleModal1"));
      modal.hide();
      document.getElementById("loginLink").style.display = "none";
      document.getElementById("signupLink").style.display = "none";
      document.getElementById("usernameDisplayContainer").style.display = "block";

      // Add additional actions if needed
    })
    .catch((error) => {
      // Handle errors
      const errorCode = error.code;
      const errorMessage = error.message;
      console.error("Sign up error:", errorCode, errorMessage);
      alert(errorMessage);
    });
});


function disableButton(buttonId) {
  document.getElementById(buttonId).disabled = true;
}


// logoutFunctions.js

// Function to handle user logout
function handleLogout() {
  auth.signOut()
    .then(() => {
      const loginLink = document.getElementById("loginLink");
      const signupLink = document.getElementById("signupLink");
      const usernameDisplayContainer = document.getElementById("usernameDisplayContainer");
      localStorage.removeItem("userEmail");

      if (loginLink && signupLink) {
        loginLink.style.display = "block";
        signupLink.style.display = "block";
      }

      if (usernameDisplayContainer) {
        usernameDisplayContainer.style.display = "none";
      }

      console.log("User logged out");
      alert("Logout successfully");
    })
    .catch((err) => {
      console.error("Logout error:", err.message);
      alert("Logout failed. Please try again.");
    });
}
document.getElementById("logout").addEventListener("click", handleLogout);



// Event listener for the Log In button
document.getElementById("loginBtn").addEventListener("click", function () {
  const email = document.getElementById("exampleFormControlInput1").value;
  const password = document.getElementById("pwd_log").value;

  // Firebase log-in
  auth.signInWithEmailAndPassword(email, password)
    .then((userCredential) => {
      // Log in successfully
      const user = userCredential.user;
      console.log("User logged in:", user);
      alert("Login successully");

      
      // Reset input fields
      email.value = '';
      password.value = '';

      // Update the username display
      const usernameDisplay = document.getElementById("usernameDisplay");

      usernameDisplay.textContent = `${user.email}!`;
      localStorage.setItem("userEmail", user.email);

      // Add additional actions if needed
      const modal = new bootstrap.Modal(document.getElementById("exampleModal1"));
      modal.hide();

      // Hide the login and signup links
      document.getElementById("loginLink").style.display = "none";
      document.getElementById("signupLink").style.display = "none";
      document.getElementById("usernameDisplayContainer").style.display = "block";
    })
    .catch((error) => {
      // Handle errors
      const errorCode = error.code;
      const errorMessage = error.message;
      console.error("Log in error:", errorCode, errorMessage);
      alert(errorMessage);
    });
});

// Check the user's authentication status
auth.onAuthStateChanged((user) => {
  const createResumeBtn = document.getElementById("createResumeBtn");

  if (user) {
    // User is logged in
    createResumeBtn.removeAttribute("disabled");

    createResumeBtn.removeEventListener("click", handleCreateResumeClick);
    createResumeBtn.addEventListener("click", handleCreateResumeClick);
  } else {
    // User is not logged in
    createResumeBtn.setAttribute("disabled", true);
    createResumeBtn.removeEventListener("click", handleCreateResumeClick);
    createResumeBtn.addEventListener("click", showLoginAlert);
  }

});

// Function to handle the click event for createResumeBtn
function handleCreateResumeClick() {
  const user = auth.currentUser;

  if (user) {
    // User is logged in
    window.location.href = "resume.html";
  } else {
    // User is not logged in
    alert("Please log in before creating a resume.");
  }
}

// Retrieve and set the user information from session storage on page load
window.addEventListener("load", () => {
  const usernameDisplay = document.getElementById("usernameDisplay");

  // Retrieve storedUserEmail from session storage
  const storedUserEmail = localStorage.getItem("userEmail");
  console.log("Retrieving userEmail from sessionStorage:", storedUserEmail);

  if (storedUserEmail) {
    // User was logged in, set the user information
    document.getElementById("loginLink").style.display = "none";
    document.getElementById("signupLink").style.display = "none";
    document.getElementById("usernameDisplayContainer").style.display = "block";

    usernameDisplay.textContent = `${storedUserEmail}!`;
  }
});
function showLoginAlert() {
  alert("Please log in before creating a resume.");
}


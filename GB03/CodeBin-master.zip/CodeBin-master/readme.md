# Abstract

It allows users to store and share plain text online. It is most commonly used to share source code, configuration data, log files and info dump amongst the software development community.

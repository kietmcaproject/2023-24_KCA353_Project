﻿namespace Hospital_Management_System
{
    partial class Diagnosis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Diagnosis));
            pictureBox3 = new PictureBox();
            label9 = new Label();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label10 = new Label();
            label11 = new Label();
            dataGridView3 = new DataGridView();
            label12 = new Label();
            addbtn = new Button();
            updatebtn = new Button();
            deletebtn = new Button();
            resetbtn = new Button();
            homebtn = new Button();
            textBox1 = new TextBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            textBox5 = new TextBox();
            comboBox = new ComboBox();
            CrossHome = new Button();
            textBox2 = new TextBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).BeginInit();
            SuspendLayout();
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(12, 12);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(125, 120);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 5;
            pictureBox3.TabStop = false;
            pictureBox3.UseWaitCursor = true;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("SimSun", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label9.Location = new Point(145, 57);
            label9.Margin = new Padding(5, 0, 5, 0);
            label9.Name = "label9";
            label9.Size = new Size(127, 23);
            label9.TabIndex = 31;
            label9.Text = "DIAGNOSIS";
            label9.UseWaitCursor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("SimSun", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(638, 153);
            label1.Margin = new Padding(5, 0, 5, 0);
            label1.Name = "label1";
            label1.Size = new Size(166, 23);
            label1.TabIndex = 32;
            label1.Text = "PATIENT NAME";
            label1.UseWaitCursor = true;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("SimSun", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(899, 153);
            label2.Margin = new Padding(5, 0, 5, 0);
            label2.Name = "label2";
            label2.Size = new Size(114, 23);
            label2.TabIndex = 33;
            label2.Text = "SYMPTOMS";
            label2.UseWaitCursor = true;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("SimSun", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(638, 249);
            label3.Margin = new Padding(5, 0, 5, 0);
            label3.Name = "label3";
            label3.Size = new Size(153, 23);
            label3.TabIndex = 34;
            label3.Text = "DIAGNOSTIC ";
            label3.UseWaitCursor = true;
            label3.Click += label3_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("SimSun", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(899, 249);
            label4.Margin = new Padding(5, 0, 5, 0);
            label4.Name = "label4";
            label4.Size = new Size(114, 23);
            label4.TabIndex = 35;
            label4.Text = "MEDICINE";
            label4.UseWaitCursor = true;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("SimSun", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(36, 379);
            label5.Margin = new Padding(5, 0, 5, 0);
            label5.Name = "label5";
            label5.Size = new Size(127, 23);
            label5.TabIndex = 36;
            label5.Text = "MEDICINES";
            label5.UseWaitCursor = true;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("SimSun", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label6.Location = new Point(36, 331);
            label6.Margin = new Padding(5, 0, 5, 0);
            label6.Name = "label6";
            label6.Size = new Size(205, 23);
            label6.TabIndex = 37;
            label6.Text = "DIAGNOSTIC TEST";
            label6.UseWaitCursor = true;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("SimSun", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label7.Location = new Point(36, 290);
            label7.Margin = new Padding(5, 0, 5, 0);
            label7.Name = "label7";
            label7.Size = new Size(114, 23);
            label7.TabIndex = 38;
            label7.Text = "SYMPTOMS";
            label7.UseWaitCursor = true;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("SimSun", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label8.Location = new Point(36, 244);
            label8.Margin = new Padding(5, 0, 5, 0);
            label8.Name = "label8";
            label8.Size = new Size(166, 23);
            label8.TabIndex = 39;
            label8.Text = "PATIENT NAME";
            label8.UseWaitCursor = true;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("SimSun", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label10.Location = new Point(36, 196);
            label10.Margin = new Padding(5, 0, 5, 0);
            label10.Name = "label10";
            label10.Size = new Size(140, 23);
            label10.TabIndex = 40;
            label10.Text = "PATIENT ID";
            label10.UseWaitCursor = true;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("SimSun", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label11.Location = new Point(36, 154);
            label11.Margin = new Padding(5, 0, 5, 0);
            label11.Name = "label11";
            label11.Size = new Size(166, 23);
            label11.TabIndex = 41;
            label11.Text = "DIAGNOSIS ID";
            label11.UseWaitCursor = true;
            // 
            // dataGridView3
            // 
            dataGridView3.BackgroundColor = Color.DeepSkyBlue;
            dataGridView3.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView3.Location = new Point(12, 441);
            dataGridView3.Name = "dataGridView3";
            dataGridView3.RowHeadersWidth = 51;
            dataGridView3.RowTemplate.Height = 29;
            dataGridView3.Size = new Size(792, 264);
            dataGridView3.TabIndex = 42;
            dataGridView3.DoubleClick += dataGridView3_DoubleClick;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("SimSun", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label12.Location = new Point(732, 51);
            label12.Margin = new Padding(5, 0, 5, 0);
            label12.Name = "label12";
            label12.Size = new Size(285, 30);
            label12.TabIndex = 43;
            label12.Text = "DIAGNOSIS SUMMARY";
            label12.UseWaitCursor = true;
            // 
            // addbtn
            // 
            addbtn.BackColor = Color.DeepSkyBlue;
            addbtn.Location = new Point(822, 441);
            addbtn.Name = "addbtn";
            addbtn.Size = new Size(112, 48);
            addbtn.TabIndex = 44;
            addbtn.Text = "ADD";
            addbtn.UseVisualStyleBackColor = false;
            addbtn.Click += addbtn_Click;
            // 
            // updatebtn
            // 
            updatebtn.BackColor = Color.DeepSkyBlue;
            updatebtn.Location = new Point(822, 495);
            updatebtn.Name = "updatebtn";
            updatebtn.Size = new Size(112, 48);
            updatebtn.TabIndex = 45;
            updatebtn.Text = "UPDATE";
            updatebtn.UseVisualStyleBackColor = false;
            updatebtn.Click += updatebtn_Click;
            // 
            // deletebtn
            // 
            deletebtn.BackColor = Color.DeepSkyBlue;
            deletebtn.Location = new Point(824, 549);
            deletebtn.Name = "deletebtn";
            deletebtn.Size = new Size(110, 48);
            deletebtn.TabIndex = 46;
            deletebtn.Text = "DELETE";
            deletebtn.UseVisualStyleBackColor = false;
            deletebtn.Click += deletebtn_Click;
            // 
            // resetbtn
            // 
            resetbtn.BackColor = Color.DeepSkyBlue;
            resetbtn.Location = new Point(824, 603);
            resetbtn.Name = "resetbtn";
            resetbtn.Size = new Size(110, 48);
            resetbtn.TabIndex = 47;
            resetbtn.Text = "RESET";
            resetbtn.UseVisualStyleBackColor = false;
            resetbtn.Click += resetbtn_Click;
            // 
            // homebtn
            // 
            homebtn.BackColor = Color.DeepSkyBlue;
            homebtn.Location = new Point(822, 657);
            homebtn.Name = "homebtn";
            homebtn.Size = new Size(112, 48);
            homebtn.TabIndex = 48;
            homebtn.Text = "HOME";
            homebtn.UseVisualStyleBackColor = false;
            homebtn.Click += homebtn_Click;
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.DeepSkyBlue;
            textBox1.Location = new Point(242, 154);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(202, 27);
            textBox1.TabIndex = 49;
            // 
            // textBox3
            // 
            textBox3.BackColor = Color.DeepSkyBlue;
            textBox3.Location = new Point(242, 286);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(202, 27);
            textBox3.TabIndex = 50;
            // 
            // textBox4
            // 
            textBox4.BackColor = Color.DeepSkyBlue;
            textBox4.Location = new Point(242, 332);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(202, 27);
            textBox4.TabIndex = 51;
            // 
            // textBox5
            // 
            textBox5.BackColor = Color.DeepSkyBlue;
            textBox5.Location = new Point(242, 380);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(202, 27);
            textBox5.TabIndex = 52;
            // 
            // comboBox
            // 
            comboBox.BackColor = Color.DeepSkyBlue;
            comboBox.FormattingEnabled = true;
            comboBox.Items.AddRange(new object[] { "A+", "B+", "O+", "A-", "B-", "O-", "AB+", "AB-" });
            comboBox.Location = new Point(242, 197);
            comboBox.Name = "comboBox";
            comboBox.Size = new Size(202, 28);
            comboBox.TabIndex = 53;
            comboBox.SelectedIndexChanged += comboBox_SelectedIndexChanged;
            comboBox.SelectionChangeCommitted += comboBox_SelectionChangeCommitted;
            // 
            // CrossHome
            // 
            CrossHome.BackColor = Color.DeepSkyBlue;
            CrossHome.Location = new Point(1104, 0);
            CrossHome.Name = "CrossHome";
            CrossHome.Size = new Size(37, 34);
            CrossHome.TabIndex = 55;
            CrossHome.Text = "X";
            CrossHome.UseVisualStyleBackColor = false;
            CrossHome.UseWaitCursor = true;
            CrossHome.Click += CrossHome_Click;
            // 
            // textBox2
            // 
            textBox2.BackColor = Color.DeepSkyBlue;
            textBox2.Location = new Point(242, 245);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(202, 27);
            textBox2.TabIndex = 56;
            // 
            // Diagnosis
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DeepSkyBlue;
            ClientSize = new Size(1141, 718);
            Controls.Add(textBox2);
            Controls.Add(CrossHome);
            Controls.Add(comboBox);
            Controls.Add(textBox5);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(textBox1);
            Controls.Add(homebtn);
            Controls.Add(resetbtn);
            Controls.Add(deletebtn);
            Controls.Add(updatebtn);
            Controls.Add(addbtn);
            Controls.Add(label12);
            Controls.Add(dataGridView3);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(label9);
            Controls.Add(pictureBox3);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Diagnosis";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Diagnosis";
            Load += Diagnosis_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }



        #endregion

        private PictureBox pictureBox3;
        private Label label9;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label10;
        private Label label11;
        private DataGridView dataGridView3;
        private Label label12;
        private Button addbtn;
        private Button updatebtn;
        private Button deletebtn;
        private Button resetbtn;
        private Button homebtn;
        private TextBox textBox1;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox5;
        private ComboBox comboBox;
        private Button CrossHome;
        private TextBox textBox2;
    }
}
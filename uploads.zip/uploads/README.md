"# food-kart" 
# foodkart

# admin07 
# admin@07
# admin07@gmail.com




# mainadmin
# main@gmail.com
# main2024
<!--footer-->
    <div class="footer">
       <p>&copy; Salon Management System Admin Panel.</p>
    </div>
        <!--//footer-->
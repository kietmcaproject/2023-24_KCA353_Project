import React from 'react';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { Box } from '@mui/material';


import './App.css';
import ExerciseDetail from './pages/ExerciseDetail';
import Home from './pages/Home';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Login from './pages/Login';
import Signup from './pages/Signup';
import "./App.css";

import firebase from "firebase/compat/app";
import "firebase/compat/firestore";
import "firebase/compat/auth";

import { useAuthState, useSignInWithGoogle } from "react-firebase-hooks/auth";
import { useCollectionData } from "react-firebase-hooks/firestore";

firebase.initializeApp({
  //your auth key
  apiKey: "AIzaSyAB5KBaN4Lu8Add1k6jEBP8daM6Y5YplV8",
  authDomain: "login-8e1bc.firebaseapp.com",
  projectId: "login-8e1bc",
  storageBucket: "login-8e1bc.appspot.com",
  messagingSenderId: "188024653992",
  appId: "1:188024653992:web:5d7913c5a032dd3f035a9d",
  measurementId: "G-XZD37FE3E8"
});

const auth = firebase.auth();
const firestore = firebase.firestore();

const App = () => {
  const [user] = useAuthState(auth);
 return (
    
 // <Navbar />
 <BrowserRouter>
 <Routes>
  <Route path="/login"  element={user ? <Navigate to="/" /> : <LogIn />} />
  <Route path="/" element={<Home props={{user, SignOut}}/>} />
  <Route path="/exercise/:id" element={<ExerciseDetail />} />
 </Routes>
 </BrowserRouter>
// <Footer/>
// </Box>
 )
 };

 function LogIn() {
  const useSignInWithGoogle = () => {
    const provider = new firebase.auth.GoogleAuthProvider();
    auth.signInWithPopup(provider);
  };
  return (
    <div className="box">
      <h3>SignIn in Fitness App</h3>
      <br>
      </br><br>
      </br>
      <br></br>
    
     
    <button className="google-signin-btn" onClick={useSignInWithGoogle}>
      
      Sign in with Google
    </button>
    </div>
  );
}

function SignOut() {
  return (
    auth.currentUser && (
      <button className="sign-out" onClick={() => auth.signOut()}>
        Sign Out
      </button>
    )
  );
}

export default App;

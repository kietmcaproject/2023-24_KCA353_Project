import { useState } from "react";
import "../App.css";

import firebase from "firebase/compat/app";
import "firebase/compat/firestore";
import "firebase/compat/auth";

import { useAuthState, useSignInWithGoogle } from "react-firebase-hooks/auth";
import { useCollectionData } from "react-firebase-hooks/firestore";
import { useRef } from "react";

firebase.initializeApp({
  //your auth key
  apiKey: "AIzaSyAB5KBaN4Lu8Add1k6jEBP8daM6Y5YplV8",
  authDomain: "login-8e1bc.firebaseapp.com",
  projectId: "login-8e1bc",
  storageBucket: "login-8e1bc.appspot.com",
  messagingSenderId: "188024653992",
  appId: "1:188024653992:web:5d7913c5a032dd3f035a9d",
  measurementId: "G-XZD37FE3E8"
});

function Login() {
  const [user] = useAuthState(auth);
  const useSignInWithGoogle = () => {
    const provider = new firebase.auth.GoogleAuthProvider();
    auth.signInWithPopup(provider);
  };
  return (
    <button className="sign-in" onClick={useSignInWithGoogle}>
      Sign in with Google
    </button>
  );
}

export default Login;
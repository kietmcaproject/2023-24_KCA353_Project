import { useEffect, useState } from 'react';
import firebase from 'firebase/app';
import 'firebase/auth';

const Dashboard = () => {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const unsubscribe = firebase.auth().onAuthStateChanged((authUser) => {
      if (authUser) {
        // User is signed in, fetch user information
        setUser(authUser);
      } else {
        // User is signed out
        setUser(null);
      }
    });

    return () => unsubscribe(); // Cleanup subscription on unmount
  }, []);

  return (
    <div>
      {user ? (
        <div>
          <h1>Welcome, {user.displayName}</h1>
          {/* Display other user information as needed */}
        </div>
      ) : (
        <p>Please sign in with Google to access the dashboard.</p>
      )}
    </div>
  );
};

export default Dashboard;
